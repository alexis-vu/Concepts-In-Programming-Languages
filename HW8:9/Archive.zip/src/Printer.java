package src;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Printer {
	protected int index;
	protected String fileName;
	protected File file;
	
	public Printer(int index) throws IOException {
		this.index = index;
		this.fileName = "PRINTER" + index;
		this.file = new File(this.fileName);
	}

	/**
	 * Prints data to PRINTER file
	 * @param data - data to print
	 * @throws InterruptedException if sleep is interrupted
	 * @throws IOException if writing error
	 */
	public void print(StringBuffer data) throws InterruptedException, IOException {
		Thread.sleep(2750);
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(this.file, true));
		writer.append(data.toString() + "\n");
		writer.close();
	}
}
