package src;
import java.io.IOException;

public class Main {
	public static void main(String args[]) {
		try {
			OS141 os = new OS141(args);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
