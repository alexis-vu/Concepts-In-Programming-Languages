package src;
import java.io.IOException;

public class PrintJobThread extends Thread {
	UserThread user;
	String fileName;
	
	public PrintJobThread(UserThread user, String fileName) {
		this.user = user;
		this.fileName = fileName;
	}
	
	public void run() {
		// find the file to print
		FileInfo info = user.diskManager.directoryManager.lookup(this.fileName);
		
		if (info != null) {
			try {
				// get info of file to read
				int start = info.startingSector;
				int disk = info.diskNumber;
				int printer = user.printerManager.request();
				StringBuffer sb = new StringBuffer();
				
				// read each sector of the file
				for (int i = 0; i < info.fileLength; ++i) {
					user.copyBuffer(sb, user.diskManager.disks[disk].read(start + i).toString());
					user.printerManager.printers[printer].print(sb);
				}
				
				// release the printer
				user.printerManager.release(printer);
			} catch (InterruptedException | IOException e) {
				e.printStackTrace();
			}
		}
	}
}
